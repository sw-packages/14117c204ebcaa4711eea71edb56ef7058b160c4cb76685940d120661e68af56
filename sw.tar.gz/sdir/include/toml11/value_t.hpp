#ifndef TOML11_VALUE_T_HPP
#define TOML11_VALUE_T_HPP

#include "fwd/value_t_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/value_t_impl.hpp" // IWYU pragma: export
#endif

#endif // TOML11_VALUE_T_HPP
