#ifndef TOML11_COMMENTS_HPP
#define TOML11_COMMENTS_HPP

#include "fwd/comments_fwd.hpp" // IWYU pragma: export

#if ! defined(TOML11_COMPILE_SOURCES)
#include "impl/comments_impl.hpp" // IWYU pragma: export
#endif

#endif // TOML11_COMMENTS_HPP
